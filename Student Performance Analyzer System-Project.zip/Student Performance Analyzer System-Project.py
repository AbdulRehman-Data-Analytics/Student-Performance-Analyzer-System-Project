# #  Student Performance Analyzer System
# import pandas as pd
# import matplotlib.pyplot as plt

# data = []

# n = int(input("Enter number of students: "))

# for i in range(n):
#     print("\nStudent", i + 1)

#     name = input("Enter name: ")
#     roll = input("Enter roll no: ")

#     math = int(input("Math marks: "))
#     physics = int(input("Physics marks: "))
#     cs = int(input("CS marks: "))

#     total = math + physics + cs
#     avg = total / 3
#     percent = (total / 300) * 100

#     if percent >= 80:
#         grade = "A"
#     elif percent >= 70:
#         grade = "B"
#     elif percent >= 60:
#         grade = "C"
#     else:
#         grade = "Fail"

#     data.append([
#         name, roll, math, physics, cs,
#         total, avg, percent, grade
#     ])

# df = pd.DataFrame(data, columns=[
#     "Name", "Roll", "Math", "Physics", "CS",
#     "Total", "Average", "Percentage", "Grade"
# ])

# print("\n--- Student Result Sheet ---")
# print(df)

# if len(df) > 0:

#     top3 = df.sort_values(
#         by="Percentage",
#         ascending=False
#     ).head(3)

#     print("\n--- Top 3 Students ---")
#     print(top3[["Name", "Percentage"]])

#     fail = df[df["Grade"] == "Fail"]

#     print("\n--- Failed Students ---")

#     if fail.empty:
#         print("No failed students")
#     else:
#         print(fail[["Name", "Roll", "Percentage"]])

#     print("\n--- Class Summary ---")
#     print("Total Students:", len(df))
#     print("Average Class Percentage:", df["Percentage"].mean())
#     print("Highest Score:", df["Percentage"].max())
#     print("Lowest Score:", df["Percentage"].min())

#     # Graph
#     plt.figure(figsize=(8, 5))

#     plt.bar(df["Name"], df["Percentage"])

#     plt.title("Student Performance")
#     plt.xlabel("Students")
#     plt.ylabel("Percentage")

#     plt.xticks(rotation=45)

#     plt.tight_layout()

#     plt.show()

# else:
#     print("No data entered")
# # Student Performance Analyzer System (No external libraries)

# # data = []

# # n = int(input("Enter number of students: "))

# # for i in range(n):
# #     print("\nStudent", i+1)

# #     name = input("Enter name: ")
# #     roll = input("Enter roll no: ")

# #     math = int(input("Math marks: "))
# #     physics = int(input("Physics marks: "))
# #     cs = int(input("CS marks: "))

# #     total = math + physics + cs
# #     avg = total / 3
# #     percent = (total / 300) * 100

# #     if percent >= 80:
# #         grade = "A"
# #     elif percent >= 70:
# #         grade = "B"
# #     elif percent >= 60:
# #         grade = "C"
# #     else:
# #         grade = "Fail"

# #     data.append([name, roll, math, physics, cs, total, avg, percent, grade])

# # # print result sheet manually
# # print("\n--- Student Result Sheet ---")
# # print("Name\tRoll\tTotal\tAvg\t%\tGrade")

# # for s in data:
# #     print(s[0], "\t", s[1], "\t", s[5], "\t", round(s[6],2), "\t", round(s[7],2), "\t", s[8])

# # # top 3 students
# # sorted_data = sorted(data, key=lambda x: x[7], reverse=True)
# # top3 = sorted_data[:3]

# # print("\n--- Top 3 Students ---")
# # for s in top3:
# #     print(s[0], "-", round(s[7],2), "%")

# # # failed students
# # print("\n--- Failed Students ---")
# # found = False

# # for s in data:
# #     if s[8] == "Fail":
# #         print(s[0], "-", s[1], "-", round(s[7],2), "%")
# #         found = True

# # if not found:
# #     print("No failed students")

# # # summary
# # print("\n--- Class Summary ---")
# # print("Total Students:", len(data))

# # total_percent = 0
# # max_percent = data[0][7]
# # min_percent = data[0][7]

# # for s in data:
# #     total_percent += s[7]

#     # if s[7] > max_percent:
# #         max_percent = s[7]

# #     if s[7] < min_percent:
# #         min_percent = s[7]

# # print("Average Class Percentage:", total_percent / len(data))
# # print("Highest Score:", max_percent)
# # print("Lowest Score:", min_percent)